// TODO: You can add observability here. For templates re-start `create-llama` with `--pro` flag to generate a new project with observability.
export const initObservability = () => {};

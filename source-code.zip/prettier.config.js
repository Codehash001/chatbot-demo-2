module.exports = {
  plugins: ["prettier-plugin-organize-imports"],
};

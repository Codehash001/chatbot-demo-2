"use client";

import { useState } from "react";
import { Upload, FileText, Loader2, CheckCircle, AlertCircle, Download } from "lucide-react";
import { useToast } from "../components/ui/use-toast";

interface ProcessingStatus {
  step: string;
  status: "pending" | "processing" | "completed" | "error";
  message: string;
}

export default function FeedData() {
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingSteps, setProcessingSteps] = useState<ProcessingStatus[]>([]);
  const [backupUrl, setBackupUrl] = useState<string | null>(null);
  const { toast } = useToast();

  const updateProcessingStep = (
    step: string,
    status: ProcessingStatus["status"],
    message: string
  ) => {
    setProcessingSteps((prev) => {
      const existing = prev.findIndex((s) => s.step === step);
      if (existing !== -1) {
        const updated = [...prev];
        updated[existing] = { step, status, message };
        return updated;
      }
      return [...prev, { step, status, message }];
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
      // Reset states when new files are selected
      setProcessingSteps([]);
      setBackupUrl(null);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files) {
      setFiles(Array.from(e.dataTransfer.files));
      // Reset states when new files are dropped
      setProcessingSteps([]);
      setBackupUrl(null);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const downloadBackup = async () => {
    if (!backupUrl) return;

    try {
      updateProcessingStep(
        "download",
        "processing",
        "Downloading backup..."
      );

      const response = await fetch(backupUrl);
      if (!response.ok) throw new Error('Download failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'backup.zip';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      updateProcessingStep(
        "download",
        "completed",
        "Backup downloaded successfully"
      );
    } catch (error) {
      updateProcessingStep(
        "download",
        "error",
        "Failed to download backup"
      );
      toast({
        title: "Download Failed",
        description: "Failed to download the backup file. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleSubmit = async () => {
    if (files.length === 0) {
      toast({
        title: "No files selected",
        description: "Please select at least one document to process.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    setProcessingSteps([]);
    setBackupUrl(null);

    try {
      // Step 1: Upload files
      updateProcessingStep(
        "upload",
        "processing",
        "Uploading documents..."
      );

      const formData = new FormData();
      files.forEach((file) => {
        formData.append("files", file);
      });

      const response = await fetch("/api/ingest", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed to process documents");
      }

      updateProcessingStep(
        "upload",
        "completed",
        "Documents uploaded successfully"
      );

      updateProcessingStep(
        "process",
        "completed",
        "Documents processed successfully"
      );

      if (data.backupUrl) {
        setBackupUrl(data.backupUrl);
        updateProcessingStep(
          "backup",
          "completed",
          "Backup is ready for download"
        );
      } else {
        updateProcessingStep(
          "backup",
          "error",
          "Backup creation failed, but documents were processed"
        );
      }

      toast({
        title: "Success!",
        description: "Documents have been processed successfully.",
      });
      setFiles([]);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
      const currentStep = processingSteps[processingSteps.length - 1]?.step || "process";
      
      updateProcessingStep(
        currentStep,
        "error",
        `Error: ${errorMessage}`
      );

      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const getStepIcon = (status: ProcessingStatus["status"]) => {
    switch (status) {
      case "processing":
        return <Loader2 className="animate-spin h-5 w-5" />;
      case "completed":
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case "error":
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold tracking-tight">Document Ingestion</h1>
          <p className="text-gray-500 mt-2">
            Upload your documents to process and index them for the chatbot
          </p>
        </div>

        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center ${
            files.length > 0 ? "border-blue-500 bg-blue-50" : "border-gray-300"
          }`}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
        >
          <input
            type="file"
            multiple
            onChange={handleFileChange}
            className="hidden"
            id="file-upload"
            disabled={isProcessing}
          />
          <label
            htmlFor="file-upload"
            className={`cursor-pointer inline-flex flex-col items-center ${
              isProcessing ? "opacity-50" : ""
            }`}
          >
            <Upload className="h-12 w-12 text-gray-400 mb-4" />
            <span className="text-gray-600">
              Drag and drop your documents here, or{" "}
              <span className="text-blue-500 hover:text-blue-600">
                click to browse
              </span>
            </span>
          </label>
        </div>

        {files.length > 0 && (
          <div className="bg-white rounded-lg shadow p-6 space-y-4">
            <h3 className="font-semibold">Selected Documents</h3>
            <div className="space-y-2">
              {files.map((file, index) => (
                <div
                  key={index}
                  className="flex items-center space-x-3 text-sm text-gray-600"
                >
                  <FileText className="h-4 w-4" />
                  <span>{file.name}</span>
                  <span className="text-gray-400">
                    ({(file.size / 1024).toFixed(1)} KB)
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {processingSteps.length > 0 && (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="font-semibold mb-4">Processing Status</h3>
            <div className="space-y-3">
              {processingSteps.map((step) => (
                <div
                  key={step.step}
                  className="flex items-center space-x-3 text-sm"
                >
                  {getStepIcon(step.status)}
                  <span
                    className={`flex-1 ${
                      step.status === "error" ? "text-red-600" : "text-gray-600"
                    }`}
                  >
                    {step.message}
                  </span>
                  {step.step === "backup" && step.status === "completed" && backupUrl && (
                    <button
                      onClick={downloadBackup}
                      className="inline-flex items-center space-x-2 text-blue-500 hover:text-blue-600"
                    >
                      <Download className="h-4 w-4" />
                      <span>Download</span>
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex justify-center">
          <button
            onClick={handleSubmit}
            disabled={isProcessing || files.length === 0}
            className={`
              inline-flex items-center px-6 py-3 rounded-lg text-white
              ${
                isProcessing || files.length === 0
                  ? "bg-gray-400 cursor-not-allowed"
                  : "bg-blue-500 hover:bg-blue-600"
              }
            `}
          >
            {isProcessing ? (
              <>
                <Loader2 className="animate-spin h-5 w-5 mr-2" />
                Processing...
              </>
            ) : (
              "Process Documents"
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

import { SourceData } from "@llamaindex/chat-ui";
import { Markdown as MarkdownUI } from "@llamaindex/chat-ui/widgets";
import { useClientConfig } from "../hooks/use-config";

const preprocessContent = (content: string) => {
  // Remove `sandbox:` from the beginning of the URL before rendering markdown
  let processedContent = content.replace(/(sandbox|attachment|snt):/g, "");
  
  // Check if content appears to be from a PDF (contains "On page" or similar markers)
  if (content.includes("On page") || content.includes("PDF")) {
    // Format PDF content with proper styling
    processedContent = processedContent
      .split('\n')
      .map(line => {
        // Format page references
        if (line.match(/^On page \d+:/)) {
          return `**${line}**\n`;
        }
        // Format PDF titles
        if (line.includes("PDF File")) {
          return `*${line}*\n`;
        }
        return line;
      })
      .join('\n')
      // Add proper spacing between sections
      .replace(/\n{3,}/g, '\n\n');
  }
  
  return processedContent;
};

export function Markdown({
  content,
  sources,
}: {
  content: string;
  sources?: SourceData;
}) {
  const { backend } = useClientConfig();
  const processedContent = preprocessContent(content);
  
  return (
    <div className="prose max-w-none">
      <MarkdownUI
        content={processedContent}
        backend={backend}
        sources={sources}
      />
    </div>
  );
}
